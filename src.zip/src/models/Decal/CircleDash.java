package models.Decal;

/**
 * Created by Matthew on 4/16/2016.
 */
public class CircleDash extends Decal {

    public CircleDash() {
        super("res/circle-dash.png");
    }
}
