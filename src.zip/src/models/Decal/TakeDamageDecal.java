package models.Decal;

/**
 * Created by Matthew on 4/16/2016.
 */
public class TakeDamageDecal extends Decal {

    public TakeDamageDecal() {
        super("res/takeDamageDecal.png");
    }
}
