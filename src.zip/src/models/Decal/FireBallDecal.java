package models.Decal;

/**
 * Created by Matthew on 4/16/2016.
 */
public class FireBallDecal extends Decal {

    public FireBallDecal() {
        super("res/Fireball.png");
    }
}
