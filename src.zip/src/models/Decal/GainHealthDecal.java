package models.Decal;

/**
 * Created by Matthew on 4/16/2016.
 */
public class GainHealthDecal extends Decal {

    public GainHealthDecal() {
        super("res/gainhealth.png");
    }
}
