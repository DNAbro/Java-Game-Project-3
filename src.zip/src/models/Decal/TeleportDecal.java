package models.Decal;

/**
 * Created by Matthew on 4/16/2016.
 */
public class TeleportDecal extends Decal {

    public TeleportDecal() {
        super("res/teleport.png");
    }
}
