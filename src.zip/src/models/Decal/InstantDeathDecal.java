package models.Decal;

/**
 * Created by Matthew on 4/16/2016.
 */
public class InstantDeathDecal extends Decal {

    public InstantDeathDecal() {
        super("res/takeDamageDecal.png");
    }
}
