package models.Stat;

public class Lives extends Key {
    //
    public Lives(int value) {
        setName("Lives");
        setValue((double)value);
    }
}
