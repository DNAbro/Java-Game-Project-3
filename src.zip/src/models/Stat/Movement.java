package models.Stat;

public class Movement extends Tertiary {
    //
    public Movement(double value) {
        setName("Movement");
        setValue(value);
    }
}
