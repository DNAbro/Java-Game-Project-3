package models.Stat;

public class Level extends Key {
    //
    public Level(int level) {
        setName("Level");
        setValue((double)level);
    }
}
