package models.Stat;

public class Attack extends Tertiary {
    //
    public Attack(double value) {
        setName("Attack");
        setValue(value);
    }
}
