package models.Item.InteractiveItems;

/*
* Implemented by Peter Camejo
*/

public class Door {
}
