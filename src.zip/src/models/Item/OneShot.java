package models.Item;

/*
* Implemented by Peter Camejo
*/

public class OneShot {
}
