package models.Signal;

/**
 * Created by walkhard on 4/7/16.
 */
public class Signal {
}
