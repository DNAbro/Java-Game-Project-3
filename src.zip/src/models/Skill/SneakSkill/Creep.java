package models.Skill.SneakSkill;
import models.Entity.*;


public class Creep extends SneakSkill {

    public Creep() {
        super("Creep", 5.0);
    }

    public void activate(Entity entity) {
        if (entity != null) {

        }
    }

    public void createSignal(models.Map.Map map, Entity entity) {

    }

}
