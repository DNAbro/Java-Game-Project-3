package models.Skill.SmasherSkill;

public class TwoHandedWeapon extends SmasherSkill {

    public TwoHandedWeapon() {
        super("Two Handed Weapon", 1, 3);
    }

}
