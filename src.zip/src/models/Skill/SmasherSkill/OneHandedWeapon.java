package models.Skill.SmasherSkill;

public class OneHandedWeapon extends SmasherSkill {

    public OneHandedWeapon() {
        super("One Handed Weapon", 1, 2);

    }

}
