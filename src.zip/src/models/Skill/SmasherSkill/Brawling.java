package models.Skill.SmasherSkill;

public class Brawling extends SmasherSkill {

    public Brawling() {
        super("Brawling", 1, 1);
    }

}
