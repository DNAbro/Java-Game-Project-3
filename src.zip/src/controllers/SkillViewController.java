package controllers;

/**
 * Created by Andy on 4/16/2016.
 */
public class SkillViewController {
}
