package utilities.KeyCommand;

/**
 * Created by denzel on 4/14/16.
 */

public interface KeyCommand {
    void execute();
}
